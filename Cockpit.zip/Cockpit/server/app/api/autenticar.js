var sqlUtil = require('../sql-util');
var bcrypt = require('bcrypt-nodejs');
 
var api = {}



api.autenticacao = function(req, res) {
  res.send('autenticação');

        
};


module.exports = api;