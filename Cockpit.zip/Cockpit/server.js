
var app = require('./server/config/express');
var https = require('https');
var fs = require('fs');

var bcrypt = require('bcrypt-nodejs');
var winston = require('winston');

require('./server/app/db/pool');


var httpsoptions = {
    pfx: fs.readFileSync('./server.pfx'),
    passphrase: 'vivi'
};

https.createServer(httpsoptions, app)
.listen(process.env.PORT || 443, function() {
	console.log('Servidor iniciado');
});