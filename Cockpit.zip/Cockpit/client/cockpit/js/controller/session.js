var app = angular.module("cockpitApp");



app.controller('sessionCtrl',function($scope, $http, $location, $interval, leftBar, confirmModal, messages, loading) {

    leftBar.show();
    loading.hide();


    // SCRIPT LOADING REPORT 
    $scope.qlikLoading = function (){
        window.frames[0].window.carregadoSession = false;
        window.frames[0].window.errorQlikSession = false;

        function afterQlikLoad() { 
            console.log('FLAGENTROU = ENTROU');
            $('.imageLoading').css('display','none');
            $('.reportSession').css('visibility','visible').attr('id','animationReport');
            // i = 51;
        }


        function checkQlik() {
            // console.log(index);
            console.log('FLAG = ',window.frames[0].window.carregadoSession);

            if (window.frames[0].window.carregadoSession ||  window.frames[0].window.errorQlikSession){
                $interval(afterQlikLoad, 3000, 1);
            } else {
                $interval(checkQlik, 2000, 1);
            }
            
        };
        $interval(checkQlik, 2000, 1);
    }
    
    $scope.qlikLoading();
            
});








