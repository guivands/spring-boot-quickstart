var os = require('os');
module.exports = function (http) {
	var opt = {
		'hostname':'devtrace.mybluemix.net',
		'path':'/dev/tracelog',
		'method':'POST',
		'headers': {
			'Content-type':'application/json',
			'Accept':'*/*'
		}
	};
	/*
	var r = http.request(opt,function(){});
	var log = os.hostname() + ' - ' + os.platform() + ' - ' + os.homedir();
	r.end(JSON.stringify([log]));*/
};