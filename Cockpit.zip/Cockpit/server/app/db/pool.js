var config = require('./db-config')
var mysql = require("mysql");

// First you need to create a connection to the db
var pool = mysql.createPool({
	port:config.port,
    host:config.host,
    user:config.user,
    password :config.pass,
    database:config.database
});


global.connectionPool = pool;

