var sqlUtil = require('../sql-util');

var api = {};

api.selectFaqOfAnswer = function (projectId, title, callback) {
   var sqlMapSelect = {
        "table": "answer",
        "fields": ["distinct title"],
        "where": {
            "projectId" : projectId,
            "title LIKE": '%'+title+'%'
        },
        "group":"code"
    };
    sqlUtil.executeQuery(sqlMapSelect, function(err, rows) {
        if (err)
			return callback(err);
        callback(null, rows);
    });	
};

function escapeRegExp(string){
    return string.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
}
api.searchAnswers = function(projectId, filter, callback) {
    var max = filter.max ? filter.max : 20;
    max = max > 100 ? 100 : max;
    var first = filter.page ? (filter.page-1) * max : 0;
    var sqlMap = {
        table: "answer",
        "fields": ["title", "code", "statusId", "count(code) as qt_code_agg"],
        where: {
            "projectId": projectId,
        },
        group:"code",
        limit: {
            "first": first,
            "max": max
        }
    };
    if (filter.title) {
        sqlMap.where["title LIKE"] = '%'+filter.title+'%';
    }
    if (filter.text) {
        var t = escapeRegExp(filter.text).replace(/  +/g, " ").replace(" ", "( *(<[^>]+>)* *)");
        sqlMap.where["text REGEXP"] = t;
    }

    sqlUtil.executeQuery(sqlMap, callback);
};



api.selectAnswerByDirectory = function (directoryId, projectId, locale, callback) {
    if (typeof(projectId) == 'function') {
        callback = projectId;
        projectId = null;
    } else if (typeof(locale) == 'function') {
        callback = locale;
        locale = null;
    }
    var sqlMapSelect = {
        "table": "answer",
        "fields": ["title", "code", "statusId", "count(code) as qt_code_agg"],
        "where": {
            "directoryId" : directoryId
        },
        "group":"code"
    };
    if (projectId)
        sqlMapSelect.where.projectId = projectId;
    if (locale)
        sqlMapSelect.where.locale = locale;
    sqlUtil.executeQuery(sqlMapSelect, function(err, rows) {
        if (err)
			return callback(err);
        callback(null, rows);
    });
};




api.selectAnswerByCode = function (code, projectId, locale, callback) {
   var sqlMapSelect = {
        "table": "answer",
        "where": {
            "code" : code,
            "projectId" : projectId,
            "locale" : locale,
        }
    };
    sqlUtil.executeQuery(sqlMapSelect, function(err, rows) {
        if (err)
			return callback(err);

        var answers = rows;
        var ids = [];
        for (i in answers) {
            answers[i].options = [];
            ids.push(answers[i].id);
        }
        
        sqlMapSelect = {
            "sql":"select * from answer_option where answerId in (:IDS:) order by answerId, optionOrder",
            "params":ids
        };
        var qms = "";
        for(var i = 0; i < ids.length; i++) {
            qms += "?" + (i+1 < ids.length ? "," : "");
        }
        sqlMapSelect.sql = sqlMapSelect.sql.replace(':IDS:', qms);
        
        sqlUtil.executeSQL(sqlMapSelect.sql, sqlMapSelect.params, function(err, rows){
            if (err)
                return callback(err);
            
            for (i in rows) {
                var row = rows[i];
                for (j in answers)
                    if (answers[j].id == rows[i].answerId)
                        answers[j].options.push(row);
            }

            callback(null, answers);
        });
    });	
};




var removeOptionPlan = function(option, planMap) {
    planMap.plan.push({
        "sqlMap": {
            "table":"answer_option",
            "where": {
                "id": option.id
            },
            "type":"delete"
        },
        "before":function(id, step) {
            step.sqlMap.where["answerId"] = id;
        },
        "after":function(rows, step) {
            return step.sqlMap.where.answerId;
        }
    });
}
var insertOptionPlan = function(option, planMap) {
    planMap.plan.push({
        "sqlMap":{
            "table": "answer_option",
            "fields": {
                "title": option.title,
                "text": option.text,
                "action" : option.action?true:false,
                "locale": option.locale,
                "optionOrder": option.optionOrder,
                "textTypeAction": option.textTypeAction
            },
            "type": "insert"
        },
        "before":function(id, step) {
            step.sqlMap.fields["answerId"] = id;
        },
        "after":function(rows, step) {
            return step.sqlMap.fields.answerId;
        }
    });
}
var updateOptionPlan = function(option, planMap) {
    planMap.plan.push({
        "sqlMap":{
            "table": "answer_option",
            "fields": {
                "title": option.title,
                "text": option.text,
                "action" : option.action?true:false,
                "locale": option.locale,
                "optionOrder": option.optionOrder,
                "textTypeAction": option.textTypeAction
            },
            "where": {
                "id":option.id
            },
            "type": "update"
        },
        "before":function(id, step) {
            step.sqlMap.fields["answerId"] = id;
        },
        "after":function(rows, step) {
            return step.sqlMap.fields.answerId;
        }
    });
}
var optionsPlan = function(options, planMap) {
    for (i in options) {
        var option = options[i];
        if (option.removed && option.id) {
            removeOptionPlan(option, planMap);
        } else if (option.id) {
            updateOptionPlan(option, planMap);
        } else {
            insertOptionPlan(option, planMap);
        }
    }
}
var updateAnswerPlan = function(answer, planMap) {
    planMap.plan.push({
        "sqlMap": {
            "table": "answer",
            "fields": {
                "code": answer.code,
                "title": answer.title,
                "transactional" : answer.transactional,
                "optionsMapping": answer.optionsMapping,
                "text": answer.text,
                "audioText": answer.audioText,
                "locale": answer.locale,
                "projectId": answer.projectId,
                "channelId": answer.channelId,
                "type": answer.type,
                "statusId": answer.statusId,
                "technicalText": answer.technicalText,
                "directoryId": answer.directoryId
            },
            "where": {
                "id": answer.id
            },
            "type": "update",
        },
        "after": function(rows, step) {
            return step.sqlMap.where.id;
        }
    });
    optionsPlan(answer.options, planMap);
}
var insertAnswerPlan = function(answer, planMap) {
    planMap.plan.push({
        "sqlMap":{
            "table": "answer",
            "fields": {
                "code": answer.code,
                "title": answer.title,
                "transactional" : answer.transactional,
                "optionsMapping": answer.optionsMapping,
                "text": answer.text,
                "audioText": answer.audioText,
                "locale": answer.locale,
                "projectId": answer.projectId,
                "channelId": answer.channelId,
                "type": answer.type,
                "statusId": answer.statusId,
                "technicalText": answer.technicalText,
                "directoryId": answer.directoryId
            },
            "type": "insert"
        }
    });
    planMap.plan.push({
        "sqlMap":"select last_insert_id() as id;",
        "after":function(rows) {
            return rows[0].id;
        }
    });
    optionsPlan(answer.options, planMap);
}
var removeAnswerPlan = function(answer, planMap) {
    for (i in answer.options) {
        var option = answer.options[i];
        planMap.plan.push({
            "sqlMap": {
                "table":"answer_option",
                "where": {
                    "id": option.id
                },
                "type":"delete"
            }
        });
    }
    planMap.plan.push({
        "sqlMap": {
            "table":"answer",
            "where": {
                "id": answer.id
            },
            "type":"delete"
        }
    });
}
var createPlan = function(answer, planMap) {
    if (!answer.transactional)answer.transactional = false;
    if (answer.id && answer.enabled) {
        updateAnswerPlan(answer, planMap);
    } else if (answer.id) {
        removeAnswerPlan(answer, planMap);
    } else {
        insertAnswerPlan(answer, planMap);
    }
}
api.processAnswers = function(answers, callback) {
    var planMap = {
        "errorCallback":callback,
        "plan":[]
    };
    
    for(i in answers) {
        createPlan(answers[i], planMap);
    }

    planMap.plan[planMap.plan.length-1].after = function() {
        callback();
    };
    
    sqlUtil.executionPlan(planMap, function(err) {
        return callback(err);
    });
}

api.delete = function(id, callback) {
    var sqlMapDelete = {
        table: "answer",
        where: {
            'id':id
        },
        type:"delete"
    };
    sqlUtil.executeQuery(sqlMapDelete, callback);
}

api.deleteAnswerByCode = function(code, projectId, locale, callback) {
    var planMap = {
        "errorCallback":callback,
        plan:[]
    };
    planMap.plan.push({
        "sqlMap":{
            "table":"answer",
            "fields":"id",
            "where":{
                "code":code,
                "projectId":projectId,
                "locale":locale
            }
        },
        "after":function(rows) {
            console.log("ids",rows);
            var ids = [];
            for (i in rows) {
                ids.push(rows[i].id);
            }
            return ids;
        }
    });
    planMap.plan.push({
        "sqlMap":{
            "sql":"delete from answer_option where answerId in (",
            "params":[]
        },
        "before":function(ids, step) {
            for (var i = 0; i < ids.length; i++) {
                step.sqlMap.sql += "?" + (i+1 < ids.length ? "," : "");
                step.sqlMap.params.push(ids[i]);
            }
            step.sqlMap.sql += ");";
            console.log("option", step.sqlMap.sql, step.sqlMap.params);
        },
        "after":function(rows,step, ids) {
            return ids;
        }
    });
    planMap.plan.push({
        "sqlMap":{
            "sql":"delete from answer where id in (",
            "params":[]
        },
        "before":function(ids, step) {
            for (var i = 0; i < ids.length; i++) {
                step.sqlMap.sql += "?" + (i+1 < ids.length ? "," : "");
                step.sqlMap.params.push(ids[i]);
            }
            step.sqlMap.sql += ");";
            console.log("answer", step.sqlMap.sql, step.sqlMap.params);
        },
        "after":function() {
            callback();
        }
    });
    sqlUtil.executionPlan(planMap);
}

api.selectDuplicateAnswer = function(answer, callback) {
    var sqlMap = {
        'table':'answer',
        'fields':'count(1) as qtd',
        'where': [
            {"locale": answer.locale},
            {"code": answer.code},
            {"projectId": answer.projectId},
            {"channelId": answer.channelId}
        ]
    };

    if (answer.id)
        sqlMap.where.push('id <> ' + answer.id);

    sqlUtil.executeQuery(sqlMap, function(err, rows) {
		if (err)
			return callback(err);
        callback(null, rows[0].qtd);
    });
}

module.exports = api;
