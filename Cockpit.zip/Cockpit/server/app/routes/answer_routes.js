var apiAnswer = require('../api/answerAPI');
var permissions = require('../../config/permissions');

module.exports = function(app) {
    
    app.post('/cockpit/v1/answers/search/:projectId',permissions.any('SEARCH_ANSWER'), permissions.projectParam(), apiAnswer.searchAnswers);
    app.post("/cockpit/v1/answers/select-distinct-faq-name/:projectId",permissions.any('SEARCH_ANSWER'),permissions.projectParam(),apiAnswer.selectFaqOfAnswer);
    app.get('/cockpit/v1/answers/:locale/directories/:directoryId/projects/:projectId',permissions.any('SEARCH_ANSWER'),permissions.projectParam() ,apiAnswer.selectAnswerByDirectory);
    app.get('/cockpit/v1/answers/:locale/:code/projects/:projectId',permissions.any('SEARCH_ANSWER'), permissions.projectParam(),apiAnswer.selectAnswerByCode);
    app.delete('/cockpit/v1/answers/:locale/:code/projects/:projectId',permissions.any('PROCESS_ANSWER'),permissions.projectParam() ,apiAnswer.deleteAnswersByCode);
    app.post('/cockpit/v1/answers',permissions.any('PROCESS_ANSWER'), apiAnswer.processAnswers);
    app.delete('/cockpit/v1/answers/:id',permissions.any('PROCESS_ANSWER'), apiAnswer.deleteAnswer);

};
