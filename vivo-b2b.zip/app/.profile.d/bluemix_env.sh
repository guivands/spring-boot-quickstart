export MANAGEMENT_SERVER_URL="https://rtmgmt.ng.bluemix.net"
export cloud_controller_url="https://api.ng.bluemix.net"
export authorization_endpoint="https://login.ng.bluemix.net/UAALoginServerWAR"
export BOOT_SCRIPT=server.js
export NODE_EXECUTABLE=node
export NODE_OPTS=""
export NODE_ARGS="null"
