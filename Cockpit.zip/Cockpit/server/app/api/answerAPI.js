var answerDAO = require('../DAO/answerDAO');
var error = require('../error/error');

var api = {}

//<--------------------------------- SELECT ------------------------------------>


//SELECT ALL DISCTINCT FAQ OF ANSWER
api.selectFaqOfAnswer = function (req, res) {
	var projectId = req.params["projectId"];
	if (!projectId)
		return error.responseReturnXHR(res, {"status":400, "returnObj":{"message":"projectId deve ser fornecido"}});

	answerDAO.selectFaqOfAnswer(projectId, req.body.title, function (err, channels) {
		error.responseReturnXHR(res, err, channels);
	});
};

api.searchAnswers = function(req, res) {
	var projectId = req.params["projectId"];
	var filter  = req.body;

	if (!filter || (!filter.title && !filter.text)) {
		return error.responseReturnXHR(res, {
			status: 400,
			returnObj: "Nenhuma informação para filtro fornecida"
		});
	}

	answerDAO.searchAnswers(projectId, filter, function(err, answers) {
		error.responseReturnXHR(res, err, answers);
	});
}



//SELECT ANSWER BY DIRECTORY
api.selectAnswerByDirectory = function (req, res) {
	var directoryId = req.params.directoryId;
	var projectId = req.params.projectId;
	var locale = req.params.locale;
	
	if (!directoryId)
		return error.responseReturnXHR(res, {"status":400, "returnObj":{"message":"directoryId deve ser fornecido"}});
	if (!projectId)
		return error.responseReturnXHR(res, {"status":400, "returnObj":{"message":"projectId deve ser fornecido"}});
	if (!locale)
		return error.responseReturnXHR(res, {"status":400, "returnObj":{"message":"locale deve ser fornecido"}});
	 
	 
	answerDAO.selectAnswerByDirectory(directoryId, projectId, locale, function (err,answer){
		if (!err && !answer)
			err = {
				"status": 204
			};
		error.responseReturnXHR(res, err, answer);
	});
};



//SELECT ANSWER BY CODE
api.selectAnswerByCode = function (req, res) {
	var code = req.params.code;
	var projectId = req.params.projectId;
	var locale = req.params.locale;

	if (!code)
		return error.responseReturnXHR(res, {"status":400, "returnObj":{"message":"code deve ser fornecido"}});
	if (!projectId)
		return error.responseReturnXHR(res, {"status":400, "returnObj":{"message":"projectId deve ser fornecido"}});
	if (!locale)
		return error.responseReturnXHR(res, {"status":400, "returnObj":{"message":"locale deve ser fornecido"}});

	answerDAO.selectAnswerByCode(code, projectId, locale, function (err,answers){
		if (!err && !answers)
			err = {
				"status": 204
			};
		error.responseReturnXHR(res, err, answers);
	});
};



//<--------------------------------- INSERT/UPDATE ------------------------------------>
//CREATE/UPDATE ANSWER
api.processAnswers = function (req, res) {
	var answers = req.body;
	
	for (i in answers) {
		var answer = answers[i];
		if (!answer.code)
			return res.status(400).end('{"message":"Código deve ser fornecido"}'); //TODO: internacionalizar erros
		if (!answer.title)
			return res.status(400).end('{"message":"Título deve ser fornecido"}'); //TODO: internacionalizar erros
		if (!answer.locale)
			return res.status(400).end('{"message":"Idioma deve ser fornecido"}'); //TODO: internacionalizar erros
		if (!answer.projectId)
			return res.status(400).end('{"message":"Projeto deve ser fornecido"}'); //TODO: internacionalizar erros
		if (!answer.type)
			return res.status(400).end('{"message":"Tipo da respostas deve ser fornecido (PRE|POST|NONE)"}'); //TODO: internacionalizar erros
		if (!answer.directoryId)
			return res.status(400).end('{"message":"Diretório deve ser fornecido"}'); //TODO: internacionalizar erros
	}

	answerDAO.selectDuplicateAnswer(answers[0], function(err, hasAnswer){
		if (err)
			return error.responseReturnXHR(res, err);
		
		if (hasAnswer)
			return error.responseReturnXHR(res, {"status":400, "returnObj":{"message":"Já existe um conteúdo com os dados de Código, Projeto, Canal e idioma fornecidos"}}); //TODO: internacionalizar erros

		answerDAO.processAnswers(answers, function (err){
			error.responseReturnXHR(res, err);
		});
	});
};



//<--------------------------------- DELETE ------------------------------------>
//DELETE ANSWER
api.deleteAnswer = function (req, res) {
	var id = req.params['id'];
	if (!id)
		return error.responseReturnXHR(res, {"status":400, "returnObj":{"message":"ID deve ser fornecido"}});

	answerDAO.delete(id, function (err){
		error.responseReturnXHR(res, err);
	});
};

api.deleteAnswersByCode = function(req, res) {
	var code = req.params.code;
	var projectId = req.params.projectId;
	var locale = req.params.locale;

	if (!code)
		return error.responseReturnXHR(res, {"status":400, "returnObj":{"message":"code deve ser fornecido"}});
	if (!projectId)
		return error.responseReturnXHR(res, {"status":400, "returnObj":{"message":"projectId deve ser fornecido"}});
	if (!locale)
		return error.responseReturnXHR(res, {"status":400, "returnObj":{"message":"locale deve ser fornecido"}});

	answerDAO.deleteAnswerByCode(code, projectId, locale, function(err){
		error.responseReturnXHR(res, err);
	});
}






module.exports = api;