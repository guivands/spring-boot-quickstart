/*global require*/
/*
 *    Fill in host and port for Qlik engine
 */
var prefix = ''; //window.location.pathname.substr( 0, window.location.pathname.toLowerCase().lastIndexOf( "/extensions" ) + 1 );

var config = {
	host: 'localhost',
	prefix: '/',
	port: '4848',
	isSecure: false
};

// var config = {
// 	host: 'localhost',
// 	prefix: '/',
// 	port: '4848',
// 	isSecure: false
// };

//to avoid errors in workbench: you can remove this when you have added an app
var app;
require.config({
	baseUrl: (config.isSecure ? "https://" : "http://" ) + config.host + (config.port ? ":" + config.port : "" ) + config.prefix + "resources"
});


require( ["js/qlik"], function ( qlik ){

	qlik.setOnError( function ( error ){
		alert( error.message );
	});

	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		qlik.resize();
	});

	//callbacks -- inserted here --
	//open apps -- inserted here --
	
	var app = qlik.openApp('Virtual Assistant.qvf', config);

	//var app = qlik.openApp('Virtual Assistant.qvf', config);
	
	
	//get objects -- inserted here --
	
	// OBS: IMPORT THE THE FOLLOWING EXTENSIONS IN QLIK SERVER: 
	// 1 - qsSimpleKPI
	// 2 - DateRangePicker
	// 3 - tableCustomAssistentVivi
	//

	  
	// <------------------------ REPORT SATISFAÇÃO --------------------------->
	
	//PART 1
	app.getObject('FILTRO_DATA_SATISFACAO','wdrpPyA');
	app.getObject('GRAFICO_EVOLUCAO_RESPOSTAS','MPTBqVd');
	app.getObject('KPI_MEDIA_REPOSTAS_DIARIAS','cRbgBRE');
	app.getObject('KPI_VOLUME_RESPOSTAS','fTtjpw');
	
	
	//PART 2
	app.getObject('TABELA_TOP12_COMENTARIOS_SATISFACAO','JcCmbUR');
	app.getObject('KPI_DUVIDAS_RESOLVIDAS','pTwUYE');
	app.getObject('GRAFICO_PIZZA_PESQUISA_SATISFACAO_CLIQUES','jbjKxWF');
	
	
	//OUTROS
	app.getObject('GRAFICO_PIZZA_PESQUISA_SATISFACAO','Vetsx');
	
	
	
	if (app) {
		app.getObject('CurrentSelections', 'CurrentSelections').then(function() {
			$(".rain").hide();
			$(".tab-content").show();
			qlik.resize();
		});
	} else {
		$(".rain").hide();
		$(".tab-content").show();
	}

});