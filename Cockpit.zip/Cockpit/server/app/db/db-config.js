module.exports = {
    port: '3306',
    host:'us-cdbr-iron-east-03.cleardb.net',
    user:'b6bd94dfa6e91f',
    pass:'a4d0d85d',
    database:'ad_0aab9b1ae79b854',
    connectionLimit: 3
}


/*
    eva-broker:
    port: '3306',
    host:'us-cdbr-iron-east-04.cleardb.net',
    user:'b8a5907767ca11',
    pass:'d5d1286d',
    database:'ad_83b43cfffc593fb',

    Pedro-peru:
    port: '3306',
    host:'us-cdbr-iron-east-03.cleardb.net',
    user:'b854c32a0f2127',
    pass:'ddc4a46e',
    database:'ad_63407b0d0a8454b',

    Base boa:
    port: '3306',
    host:'us-cdbr-iron-east-03.cleardb.net',
    user:'b6bd94dfa6e91f',
    pass:'a4d0d85d',
    database:'ad_0aab9b1ae79b854',
*/