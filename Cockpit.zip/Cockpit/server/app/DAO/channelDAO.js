var sqlUtil = require('../sql-util');

var api = {}

//<--------------------------------- SELECT ------------------------------------>
//SELECT ALL CHANNEL IN DATABASE.
api.select = function (projectId, callback) {
	
    var sqlMapSelect = {
        "table": "channel c, channel_classification cl",
        "fields": ['c.id','c.name','c.projectId','c.classificationId','c.description','cl.name as classificationName'],
        "where": [
            "c.classificationId = cl.id",
            {"c.projectId": projectId}
        ]
    };

    sqlUtil.executeQuery(sqlMapSelect, function(err, rows) {
		if (err)
			return callback(err);

        callback(null, rows);
    });
        	
};



//SELECT CHANNEL IN DATABASE BY ID
api.selectChannelById = function (projectId, id, callback) {
    var sqlMapSelect = {
        "table": "channel",
        "where": {
            "id" : id,
            "projectId": projectId
        }
    };

    sqlUtil.executeQuery(sqlMapSelect, function(err, rows) {
		if (err)
			return callback(err);
        
        callback(null, rows.length > 0 ? rows[0] : null);
    });
        	
};


//SELECT COUNT NAME IN DATABASE
api.selectCountByName = function (name, id, callback) {
    var sqlMapSelect = {
        "table": "channel",
        "where": [
            {"name": name}
        ],
        "fields": "count(1) as qt"
    };
    if (id)
        sqlMapSelect.where.push(" id <> " + id + " ");

    sqlUtil.executeQuery(sqlMapSelect, function(err, rows) {
        if (err)
            return callback(err);
        callback(null, rows[0].qt);
    });
}



//<------------------------------- INSERT ----------------------------------->
//VALIDADE IF EXISTS CHANNEL IN DATABASE AND INSERT BY PARM sqlMapInsert
api.insert = function (channel, callback) {
    var sqlMapInsert = {
        "table": "channel",
        "fields":{
            "name": channel.name,
            "projectId": channel.projectId,
            "classificationId": channel.classificationId,
            "description": channel.description
            },
        "type":"insert"
        };

    sqlUtil.executeQuery(sqlMapInsert, function(err) {
            if (err)
            return callback(err);
        callback();
    });
};


//<--------------------------------- UPDATE ------------------------------------>
//UPDATE CHANNEL BY PARM sqlMapUpdate
api.update = function(channel, callback) {
    var sqlMapUpdate = {
        'table':'channel',
        'fields':{
            'name':channel.name,
            "classificationId": channel.classificationId,
            "description": channel.description
        },
        'where': {
            'id':channel.id,
            'projectId':channel.projectId
        },
        'type':'update'
    };

    sqlUtil.executeQuery(sqlMapUpdate, function(err, rows) {
		if (err)
			return callback(err);
        callback();
    });
        
};



//<--------------------------------- DELETE ------------------------------------>


//DELETE CHANNEL BY PARM sqlMapDelete
api.delete = function (projectId, id, callback) {
	
    var sqlMapDelete = {
        table: "channel",
        where: {
            'id':id,
            'projectId':projectId
        },
        type:"delete"
    };
    
    sqlUtil.executeQuery(sqlMapDelete, function(err) {
       
		if (err)
			return callback(err);

        callback();
        
    });
        	
};




module.exports = api;

