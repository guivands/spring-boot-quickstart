var http = require('http');
var app = require('./config/express');

var cors = require('cors');
app.use(cors());

app.set('view engine', 'ejs');

app.get('/js/main2.js', (req, res)=> {
	res.set('Content-Type', 'text/javascript');
	res.render("main2", {phone:req.query.phone});
});

app.get('/js/mobile.js', (req, res)=> {
	res.set('Content-Type', 'text/javascript');
	res.render("mobile", {phone:req.query.phone});
});

http.createServer(app)
.listen(process.env.PORT || 5000, function() {
	console.log('Servidor iniciado CHAT');
});

 

//var server = app.listen(process.env.PORT || 3000, process.env.IP || "0.0.0.0", function(){
//  var addr = server.address();
//  logger.info("Servidor iniciado em", addr.address + ":" + addr.port);
//});