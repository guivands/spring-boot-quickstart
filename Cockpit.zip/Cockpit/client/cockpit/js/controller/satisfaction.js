var app = angular.module("cockpitApp");


app.controller('satisfactionCtrl',function($scope, $http, $location, $interval, leftBar, confirmModal, messages, loading) {
    
    leftBar.show();

    loading.hide();
    
    // SCRIPT LOADING REPORT 
    $scope.qlikLoading = function (){
            window.frames[0].window.carregadoSatisfaction = false;
            window.frames[0].window.errorQlikSatisfaction = false;

            
            function afterQlikLoad() { 
                console.log('FLAGENTROU = ENTROU');
                $('.imageLoading').css('display','none');
                $('.reportSatisfaction').css('visibility','visible').attr('id','animationReport');
            }

            function checkQlik() {
                // console.log(index);
                console.log('FLAG = ',window.frames[0].window.carregadoSatisfaction);

                if (window.frames[0].window.carregadoSatisfaction ||  window.frames[0].window.errorQlikSatisfaction){
                    $interval(afterQlikLoad, 3000, 1);
                } else {
                    $interval(checkQlik, 2000, 1);
                }
                
            };
            $interval(checkQlik, 2000, 1);
        }


        $scope.qlikLoading();

});








