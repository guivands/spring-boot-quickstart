
$(function(){


var telefone = "";

var parser = new UAParser(); 
var reproduzAudio = false;
var mapActive = true;
var origemRota = "";
var codSend = "";
var destinoRota = "";
var mapSlide = false;
var texto = "";
var context_Returned = "";
var recording = false;
var tel = "";
var i = 0;
//var context = new AudioContext();
//Ajax
var ajaxURL = "https://eva-broker.mybluemix.net/api/conversations/"+ context_Returned; //"http://localhost:51480/api/mapfre/conversation"; "http://netcorecontroler.mybluemix.net/api/mapfre/conversation"
var ajaxType = "POST";
var ajaxResponseParseMethod = "json";
var ajaxCrossDomain = true;
var headersAjax = {
        'Accept': 'application/json',
        'Content-type': 'application/json',
        'PROJECT': 'B2C',
        'CHANNEL': 'Movel',
        'API-KEY': '56448193-695a-40b4-9ffc-28891a758034',
        'OS': parser.getOS().name,
        'OS-VERSION': parser.getOS().version,
        'BROWSER': parser.getBrowser().name,
        'BROWSER-VERSION': parser.getBrowser().version,
        'LOCALE': 'pt-BR',
         'USER-REF': "127.0.0.1",
         'BUSINESS-KEY': telefone
        };
      $('.input-iniciar').mask('(99) 9999-99999');

      $("#telenviar").click(function(){

            var text = $('.input-iniciar').val();
            var tel = text.replace(/[^0-9]/g,'');

            $('#tel').css('display','none');
            $('#chat').css('display','block');
            
            // if ($('.input-iniciar').val() != ""){
                

            // }
            // else{
            // //limpar        
            // $('.input-iniciar').val('');
            // }
            
        headersAjax = {
                'Accept': 'application/json',
                'Content-type': 'application/json',
                'PROJECT': 'B2C',
                'CHANNEL': 'Movel',
                'API-KEY': '56448193-695a-40b4-9ffc-28891a758034',
                'OS': parser.getOS().name,
                'OS-VERSION': parser.getOS().version,
                'BROWSER': parser.getBrowser().name,
                'BROWSER-VERSION': parser.getBrowser().version,
                'LOCALE': 'pt-BR',
                'USER-REF': "127.0.0.1",
                'BUSINESS-KEY': tel
                };
       

        });

             
    //mudar cor quando focado
     $(".input-iniciar").focus(function(){

        // $(this).css('border', 'rgba(0, 0, 255, 0.41) solid 2px')
               //  .css('box-shadow','0 0px 12px 4px rgba(0, 0, 255, 0.41)')

        });



    //scroll da tela
    $(".scroll").scroll();

    // evento click no ENTER adicionar no chat 
    $('#txtarea').keypress(function (event) {
        if (event.which == 13) {
               $("#enviar").click();
                

        }

    });
    $('.input-iniciar').keypress(function (event) {
        if (event.which == 13) {
                $("#telenviar").click();
                

        }

    });

  // Adicionar no chat 
   $("#enviar").click(function(){
          var text = $('#txtarea').val();
         
         if ($('#txtarea').val() != ""){
                $(".scroll").append("<div class='chat-message row'><div class='usuario'><i class='seta-direita'></i><span><strong class='font-chat'>Você: </strong> " + text + "</span></div></div>");
                // atualizar scroll para baixo
                scrollToDown();
                //Enviar para Watson
                // $("#txtarea").css('background', 'rgba(128,128,128,0.1)');
                 $("#txtarea").attr('placeholder','Por favor Aguarde ...');
                 $("#txtarea").attr('disabled','disabled');
                 $("#enviar").attr('disabled','disabled');
                sendMensagemWatson(text);          
            }
            else
            {
                 // $("#txtarea").css('border', 'rgba(255, 0, 0, 0.73) solid 2px')
                   //             .css('box-shadow','0 0px 12px 4px rgba(255, 0, 0, 0.73)');
            }
            //limpar        
            $('#txtarea').val('');

        });

    //mudar cor quando focado
     $("#txtarea").focus(function(){

        // $(this).css('border', 'rgba(0, 0, 255, 0.41) solid 2px')
          //       .css('box-shadow','0 0px 12px 4px rgba(0, 0, 255, 0.41)')

                

        });

        
    var startRecorder = function(recorder) {
        recorder.clear();
        recorder.record();
        console.log('1');
        recording = true;

    }

    var stopRecorder = function(recorder) {
        recorder.stop();
        recorder.exportWAV(function(wav) {
        var url = window.webkitURL.createObjectURL(wav);
        $(".scroll").append("<div class='chat-message row'> <div class='usuario col-xs-12 col-sm-10 '><span> <audio id="+i+" controls='controls'> </audio> </span></div><div class='usuario-logo col-xs-6 col-md-4 col-sm-2'> <img class='img-logo' src='img/userChat.png'></div></div>");
        scrollToDown();
        stringAudio(wav);
        $("audio#"+ i +"").attr("src", url);
        $("audio#"+ i +"").get()[0].load();
    recording = false;
        });
    i++;
    }

    var playbackRecorderAudio = function (recorder, context) {
        recorder.getBuffer(function (buffers) {
        var source = context.createBufferSource();
        source.buffer = context.createBuffer(1, buffers[0].length, 48000);
        source.buffer.getChannelData(0).set(buffers[0]);
        source.buffer.getChannelData(0).set(buffers[1]);
        source.connect(context.destination);
        source.noteOn(0);   
        });
    }


   // navigator.webkitGetUserMedia({"audio": true}, function(stream) {
    
  //     var audioContext = new webkitAudioContext();
   //     var mediaStreamSource = audioContext.createMediaStreamSource( stream );
    //    mediaStreamSource.connect( audioContext.destination );

     //   var recorder = new Recorder(mediaStreamSource, {
     //   workerPath: "js/rew.js"
     //   });

   // $('#record-toggle').bind( "touchstart", function (event) {
//
   //                 startRecorder(recorder);
   //                 recording = true;
    //                $("#txtarea").attr("placeholder", "Gravando...");
                
     //   });

     //   $('#record-toggle').bind( "touchend", function (event) {
            
      //          stopRecorder(recorder);
       //             recording = false;
       //             $("#txtarea").attr("placeholder", "Digite algo aqui...");

       // });
    
      //  $("#webaudio-playback").click(function (e) {
      //  e.preventDefault();
     //   playbackRecorderAudio(recorder, audioContext);
       // })

   // }, 

   // function(error) {
   //     alert("Error: you need to allow this sample to use the microphone.");
   // });


function sendMensagemWatson(usermessage) {

    /* Define estrutura da mensagem para ser enviada via JSON ao servidor */
 ajaxURL = "https://eva-broker.mybluemix.net/api/conversations/"+ context_Returned;
   
    var response_Returned = "";
    var dialogStack_Returned = "";
    var dialog_turn_counter_Returned = 0;
    var dialog_request_counter_Returned = 0;

    if ($('.scroll').data('context') != null) {
        context_Returned = JSON.stringify($('.scroll').data('context'));
    }
   
    var message = {
        text: usermessage,
        returnAudio: false
    };

     if(codSend)
        message.code = codSend;
  
  
    console.log(message);

    /* Define AJAX Settings */
    jQuery.support.cors = true;
    var ajaxDataToTarget = message;  

                            
console.log(headersAjax);

    jQuery.ajax({
        
         headers:headersAjax,                     
         type: ajaxType	,							 
         url: ajaxURL,									
         crossDomain: ajaxCrossDomain,		    
         data: JSON.stringify(ajaxDataToTarget),	
         dataType: ajaxResponseParseMethod,		
         success:function(data) {
         console.log(data);
            answerAssistant(data);
           
           // if (data.output.mapa.activeMap == true){
             //   Mapa(data.output.mapa.origem, data.output.mapa.destino);
             //    $('#texto').html("<div class='chat-message row'><div class='message-logo col-xs-1 col-md-4 col-sm-2'><img class='img-logo' src='img/logoChat.png'></div><div class='message col-xs-12 col-sm-10 col-md-8'><span> " + data.output.mapa.origem + " " + data.output.mapa.destino + " </span></div></div>");
          //  }

            //Gravar ID da conversa
            console.log(data.sessionCode);
            if(data.sessionCode)
            context_Returned = data.sessionCode;

             ajaxURL = "https://eva-broker.mybluemix.net/api/conversations/"+ context_Returned
            console.log(ajaxURL);
    }						        /* true - will cache URL data returned; false - will not cache URL data but only for HEAD AND GET requests */
   
 })
  
}



function  stringAudio(blob) {
    var reader = new window.FileReader();
    reader.readAsDataURL(blob); 
    reader.onloadend = function() {
        base64data = reader.result;   
        sendAudioWatson(base64data.substring("data:audio/wav;base64,".length));
    }
}

function  sendAudioWatson(encodedString) {

    if ($('.scroll').data('context') != null) {
        context_Returned = JSON.stringify($('.scroll').data('context'));
    }
  
    var message = {
        returnAudio: true,
         "audio":{
                  "type":"audio/wav",
                  "length":encodedString.length,
                  "content":encodedString,
                }
            }      

    /* Define AJAX Settings */
    jQuery.support.cors = true;
   var ajaxDataToTarget = message; 

    jQuery.ajax({
        
         headers:headersAjax,                     
         type: ajaxType,							 
         url: ajaxURL,									
         crossDomain: ajaxCrossDomain,		    
         data: JSON.stringify(ajaxDataToTarget),	
         dataType: ajaxResponseParseMethod,		
        success:function(data) {
            console.log(data);
            answerAssistantAudio(stringToByteArray(atob(data.intent.audio.content)), data);
           // if (data.output.mapa.activeMap == true){
            //    Mapa(data.output.mapa.origem, data.output.mapa.destino);
            //     $('#texto').html("<div class='chat-message row'><div class='message-logo col-xs-1 col-md-4 col-sm-2'><img class='img-logo' src='img/logoChat.png'></div><div class='message col-xs-12 col-sm-10 col-md-8'><span> " + data.output.mapa.origem + " " + data.output.mapa.destino + " //</span></div></div>");
          //  }

            //Gravar ID da conversa
            context_Returned = data.sessionCode;
  
    }						        /* true - will cache URL data returned; false - will not cache URL data but only for HEAD AND GET requests */
   
 })
  
}


       $(".scroll").delegate("#lis-poup", "click",function(){
          
                 console.log($(this).data('text'));
              var title = $(this).data('title');
               
               
        if (mapSlide == false) {

            //Animação da aba
            $('#aba_mapa').animate({
                left: '250px', opacity: 0.1
            });
              
            $('#exibir').css('display', 'block');
            $('#title-tela').html(title + " <i id='fechar' class='fa fa-times' aria-hidden='true'style='position: absolute;right: 37px;top: 13px;'></i>");
            $("#fechar").click(function(){   
                 $('#exibir').css('display', 'none');
            });
           

            //Animação da área completa do mapa         style="padding: -0px 35px 0px 24px;text-align: justify;line-height: 43px;"
            $('#area_mapa').html($(this).data('text')).css("padding","-0px 35px 0px 24px").css("text-align","justify").css("line-height", "43px");
          
        }
        else {
            //Animação da aba
            $('#aba_mapa').animate({
                left: '250px', opacity: 1
            },
            {
                complete: function () {
                    $('#seta_mapa').css('background', 'url("../images/mapfre/seta_direita_gray.gif") no-repeat center')
                    $('#aba_mapa').animate({ left: '275px', opacity: 1 });
                }
            });

            //Animação da área completa do mapa
            $('#area_mapa').css('display', 'none');
            $('#area_mapa').animate({
                left: '0px', opacity: 0.2, width: '0px', height: '0px'
            },
            {
                complete: function () {

                    //Chamar uma função para limpar o mapa
                    var directionsService = new google.maps.DirectionsService;
                    var directionsDisplay = new google.maps.DirectionsRenderer;

                    var map = new google.maps.Map(document.getElementById('area_mapa'));

                    directionsDisplay.setMap(map)
                }
            },
            1500);

            mapSlide = 0;
        }
                 
                 
                 });
        
    // função para monstar a resposta (texto)
    function answerAssistant(texto){
       try{
           if(texto == undefined){
                 $(".scroll").append("<div class='chat-message row'> <div class='message-logo col-xs-1 col-md-4 col-sm-2'> <div class='img-logo-watson'></div></div> <div class='message-vivi col-xs-12 col-sm-8 col-md-8'><i class='seta-esquerda'></i> <span class='mensagem-vivi-titulo'><strong>Vivi:</strong></span>Desculpa, Eu não entendi<span></lu></span></div></div>");    
             }else{
                if(texto.answers[0].options.length != undefined){   
                        var html = "<lu style='list-style-type: none;'>";
                            for(var i=0; i<texto.answers[0].options.length; i++){
                            
                                    html +="<li><i class='fa fa-circle i' aria-hidden='true'> </i><a id='lis-poup' data-text='" + texto.answers[0].options[i].text  + "' data-title='" +  texto.answers[0].options[i].title + "'>" + texto.answers[0].options[i].title  + "</a></li>" ;
                        
                            } 

                        $(".scroll").append("<div class='chat-message row'> <div class='message-logo col-xs-1 col-md-4 col-sm-2'> <div class='img-logo-watson'></div></div> <div class='message-vivi col-xs-12 col-sm-8 col-md-8'><i class='seta-esquerda'></i> <span class='mensagem-vivi-titulo'><strong>Vivi:</strong></span><span>"+ texto.answers[0].text +"</span><span>"+ html + "</lu></span></div></div>");
        
                }else{ $(".scroll").append("<div class='chat-message row'> <div class='message-logo col-xs-1 col-md-4 col-sm-2'> <div class='img-logo-watson'></div></div> <div class='message-vivi col-xs-12 col-sm-8 col-md-8'><i class='seta-esquerda'></i> <span class='mensagem-vivi-titulo'><strong>Vivi:</strong></span><span>"+texto.answers[0].text   + "</lu></span></div></div>");}

             }   
          
         scrollToDown();
       }catch(err){

                $(".scroll").append("<div class='chat-message row'> <div class='message-logo col-xs-1 col-md-4 col-sm-2'> <div class='img-logo-watson'></div></div> <div class='message-vivi col-xs-12 col-sm-8 col-md-8'><i class='seta-esquerda'></i> <span class='mensagem-vivi-titulo'><strong>Vivi:</strong></span><span class='msgvivi'>"+texto.answers[0].text   + "</lu></span></div></div>");
        
            scrollToDown();
       }

                 $("#txtarea").css('background', 'white');
                 $("#txtarea").attr('placeholder','Escreva sua Pergunta');
                 $("#txtarea").removeAttr('disabled');
                 $("#enviar").removeAttr('disabled');

    }

    // função para monstar a resposta (Audio)
    function answerAssistantAudio(byteArray, texto){
    
        $(".scroll").append("<div class='chat-message row'> <div class='message-logo col-xs-1 col-md-4 col-sm-2'> <div class='img-logo-watson'></div></div> <div class='message-vivi col-xs-12 col-sm-8 col-md-8'><i class='seta-esquerda'></i> <span class='mensagem-vivi-titulo'><strong>Vivi:</strong></span><span>" + texto.intent.text + "</span></div></div>");
           scrollToDown();
    console.log(typeof byteArray, byteArray.length);
	var arrayBuffer = new ArrayBuffer(byteArray.length);
	var bufferView = new Uint8Array(arrayBuffer);
	for (i = 0; i < byteArray.length; i++) {
		bufferView[i] = byteArray[i];
	}
	console.log('Oi', arrayBuffer);
	context.decodeAudioData(arrayBuffer, function(buffer) {
		buf = buffer;
		console.log('bom ?');
		play();
	});

    }

    function init() {
	if (!window.AudioContext) {
		if (!window.webkitAudioContext) {
			alert("Your browser does not support any AudioContext and cannot play back this audio.");
			return;
		}
		window.AudioContext = window.webkitAudioContext;
	}

}


   var stringToByteArray = function(str) {
    var bytes = [];
    for (var i = 0; i < str.length; ++i) {
        bytes.push(str.charCodeAt(i));
    }
    return bytes;
};

function play() {
	// Create a source node from the buffer
	var source = context.createBufferSource();
	source.buffer = buf;
	// Connect to the final output node (the speakers)
	source.connect(context.destination);
	// Play immediately
	source.start(0);
}


	
        // função para jogar sempre para baixo o scroll
        function scrollToDown() {
            //calculo para pegar a medida do celular até o topo
            var topo = $('.form').position().top;

            var t = 40;
            var result = topo - t;

            $('.scroll').css('height', result);
            $('.scroll').scrollTop($('.scroll')[0].scrollHeight);
        }

        function Mapa(origem, destino){
            mapActive = true;
            origemRota = origem;
            destinoRota = destino;

             $('#seta_mapa').click();
      
         }
          

         function DesativaUsoMapa() {
                if (mapSlide == true)
                {
                    $('#seta_mapa').click();
                }
              
            }
  
// Mostrar uma nova ABA
  $('#seta_mapa').click(function () {

        if (mapSlide == false) {

            //Animação da aba
            $('#aba_mapa').animate({
                left: '250px', opacity: 0.1
            });

            $('#exibir').css('display', 'block');
            $('#title-tela').html("Corretor <i id='fechar'  style='position: absolute;right: 61px;top: 36px;'></i>");
            $("#fechar").click(function(){
                 $('#exibir').css('display', 'none');
            });
           

            //Animação da área completa do mapa
            $('#area_mapa').css('display', 'block');
            $('#area_mapa').animate({
                left: '0px', opacity: 1, width: '100%', height: '726px'
            },
            {
                complete: function () {

                    //Função para setar a rota, deve se enviar os parâmetros de origem e destino identificados
                    calculateAndDisplayRoute(origemRota, destinoRota);
                    $('#seta_mapa').css('background', 'url("../images/mapfre/close_icon.png") no-repeat center');
                    $('#aba_mapa').css('left', '676px');
                    $('#aba_mapa').css('opacity', '1');
                }
            },
            1500);

            mapSlide = false;
        }
        else {
            //Animação da aba
            $('#aba_mapa').animate({
                left: '250px', opacity: 1
            },
            {
                complete: function () {
                    $('#seta_mapa').css('background', 'url("../images/mapfre/seta_direita_gray.gif") no-repeat center')
                    $('#aba_mapa').animate({ left: '275px', opacity: 1 });
                }
            });

            //Animação da área completa do mapa
            $('#area_mapa').css('display', 'none');
            $('#area_mapa').animate({
                left: '0px', opacity: 0.2, width: '0px', height: '0px'
            },
            {
                complete: function () {

                    //Chamar uma função para limpar o mapa
                    var directionsService = new google.maps.DirectionsService;
                    var directionsDisplay = new google.maps.DirectionsRenderer;

                    var map = new google.maps.Map(document.getElementById('area_mapa'));

                    directionsDisplay.setMap(map)
                }
            },
            1500);

            mapSlide = 0;
        }
    });

                /* Função que permite calcula a rota no mapa ---------------------------------------------------------------------------- */
        function calculateAndDisplayRoute(origem, destino) {
            var directionsService = new google.maps.DirectionsService;
            var directionsDisplay = new google.maps.DirectionsRenderer;

            var map = new google.maps.Map(document.getElementById('area_mapa'));

            directionsDisplay.setMap(map);

            directionsService.route({
                origin: origem,
                destination: destino,
                travelMode: google.maps.TravelMode.DRIVING
            }, function (response, status) {
                if (status === google.maps.DirectionsStatus.OK) {
                    directionsDisplay.setDirections(response);
                     directionsDisplay.setMap(map)
                } else {
                    window.alert('Directions request failed due to ' + status);
                }
            });
        }


 
});