/*global require*/
/*
 *    Fill in host and port for Qlik engine
 */
var prefix = ''; //window.location.pathname.substr( 0, window.location.pathname.toLowerCase().lastIndexOf( "/extensions" ) + 1 );

var config = {
	host: '104.197.164.100',
	prefix: '/',
	port: '8443',
	isSecure: true
};


//to avoid errors in workbench: you can remove this when you have added an app
var app;
require.config({
	baseUrl: (config.isSecure ? "https://" : "http://" ) + config.host + (config.port ? ":" + config.port : "" ) + config.prefix + "resources"
});


require( ["js/qlik"], function ( qlik ){

	qlik.setOnError( function ( error ){
		alert( error.message );
	});

	$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
		qlik.resize();
	});

	//callbacks -- inserted here --
	//open apps -- inserted here --
	var app = qlik.openApp('b9eb331e-e520-4e2d-96ff-1c37b889026f', config);
	
	
	//get objects -- inserted here --
	
	// OBS: IMPORT THE THE FOLLOWING EXTENSIONS IN QLIK SERVER: 
	// 1 - qsSimpleKPI
	// 2 - DateRangePicker
	// 3 - tableCustomAssistentVivi
	//
	// <-------------------------- REPORT SESSION --------------------------->
	
	//PART 1
	app.getObject('GRAFICO_EVOLUCAO_SESSOES_CANAIS','KRvamE');
	app.getObject('KPI_PROJECAO_SESSOES_MES','AJXqA');
	app.getObject('KPI_MEDIA_SESSOES_DIARIAS','QjTAKE');
	app.getObject('KPI_MEDIA_PERGUNTAS_SESSAO','QyzQHW');
	app.getObject('FILTRO_DATA_SESSION','AMyus');
	app.getObject('FILTRO_CANAL','sVUWytq');
	
	
	//PART 2
	app.getObject('KPI_DADOS_GERAIS_SESSOES','JCnPzX');
	app.getObject('BAR_PORCENTAGEM_SESSOES_ATENDIDAS','gREmeeP');
	app.getObject('KPI_DADOS_GERAIS_INFORMACIONAL','apLpr');
	app.getObject('BAR_PORCENTAGEM_SESSOES_INFORMACIONAIS','YujXJ');
	app.getObject('KPI_DADOS_GERAIS_ENCONTRADOS','QjApJpx');
	app.getObject('KPI_DADOS_GERAIS_NAO_ENCONTRADOS','HbWCbZX');
	app.getObject('BAR_PORCENTAGEM_SESSOES_ENCONTRADAS','mACHfP');
	

	//PART 3
	app.getObject('TABELA_TOP10_FAQ','TwQYbh');
	app.getObject('GRAFICO_RANKING_TOP10_FAQ','XcPSbu');
	app.getObject('TABELA_TOP10_USER_INPUT','RCh');
	
	
	 
	 
	// <-------------------------- REPORT QUESTIONS --------------------------->
	
	//PART 1
	app.getObject('GRAFICO_EVOLUCAO_PERGUNTAS','phpML');
	app.getObject('KPI_VOLUME_PERGUNTAS','fysV');
	app.getObject('KPI_MEDIA_PERGUNTAS_DIARIAS','pJDXXQq');

	
	//PART 2
	app.getObject('KPI_STATUS_PERGUNTAS_TOTAL','SWDtJy');
	app.getObject('BAR_PORCENTAGEM_STATUS_PERGUNTAS','HQpm');
	app.getObject('KPI_STATUS_PERGUNTA_ENCONTRADAS','JmbJR');
	app.getObject('KPI_STATUS_PERGUNTA_NAO_ENCONTRADAS','btajWSG');
	app.getObject('BAR_PORCENTAGEM_STATUS_PERGUNTAS_ENCONTRADAS','rhszpm');
	app.getObject('KPI_MEDIA_PERGUNTAS_DIARIAS_POR_USUARIO','mkcpV');
	
	
	//PART 3
	app.getObject('TABELA_TOP5_PERGUNTAS','zckXU');
	app.getObject('TABELA_TOP5_COMENTARIOS_SATISFACAO','Abnsnr');
	app.getObject('GRAFICO_PIZZA_PESQUISA_SATISFACAO','Vetsx');
	app.getObject('GRAFICO_PIZZA_PESQUISA_QUANTIDADE_CANAL','hPVMch');
	
	
	//PART 4
	app.getObject('FILTRO_FAQ','JYEkZa');
	app.getObject('FILTRO_PALAVRA_USER_INPUT','fjyQPX');
	
	  
	  
	  
	// <------------------------ REPORT SATISFAÇÃO --------------------------->
	
	//PART 1
	app.getObject('FILTRO_DATA_SATISFACAO','wdrpPyA');
	app.getObject('GRAFICO_EVOLUCAO_RESPOSTAS','MPTBqVd');
	app.getObject('KPI_MEDIA_REPOSTAS_DIARIAS','cRbgBRE');
	app.getObject('KPI_VOLUME_RESPOSTAS','fTtjpw');
	
	
	//PART 2
	app.getObject('TABELA_TOP12_COMENTARIOS_SATISFACAO','JcCmbUR');
	app.getObject('KPI_DUVIDAS_RESOLVIDAS','pTwUYE');
	app.getObject('GRAFICO_PIZZA_PESQUISA_SATISFACAO_CLIQUES','jbjKxWF');
	
	
	
	
	
	
	if (app) {
		app.getObject('CurrentSelections', 'CurrentSelections').then(function() {
			$(".rain").hide();
			$(".tab-content").show();
			qlik.resize();
		});
	} else {
		$(".rain").hide();
		$(".tab-content").show();
	}

});