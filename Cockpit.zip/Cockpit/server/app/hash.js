var bcrypt = require('bcrypt-nodejs');

console.log(bcrypt.hashSync("admin"));