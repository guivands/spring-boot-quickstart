var app = angular.module("cockpitApp");
//var loadingQlik = require('../qlik/qlik_loading.js');

app.controller('questionCtrl',function($scope, $http, $location, $interval, leftBar, confirmModal, messages, loading) {
    
    leftBar.show();

    loading.hide();

    
    $scope.qlikLoading = function (){
            window.frames[0].window.carregadoQuestion = false;
            window.frames[0].window.errorQlikQuestion = false;

            
            function afterQlikLoad() { 
                console.log('FLAGENTROU = ENTROU');
                $('.imageLoading').css('display','none');
                $('.reportQuestion').css('visibility','visible').attr('id','animationReport');
            }

            function checkQlik() {
                // console.log(index);
                console.log('FLAG = ',window.frames[0].window.carregadoQuestion);

                if (window.frames[0].window.carregadoQuestion ||  window.frames[0].window.errorQlikQuestion){
                    $interval(afterQlikLoad, 3000, 1);
                } else {
                    $interval(checkQlik, 2000, 1);
                }
                
            };
            $interval(checkQlik, 2000, 1);
        }

        $scope.qlikLoading();

});








