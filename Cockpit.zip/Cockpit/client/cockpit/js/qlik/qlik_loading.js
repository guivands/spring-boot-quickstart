

function qlikLoading(){
    
window.frames[0].window.carregado = false;
window.frames[0].window.errorQlik = false;

 console.log('0000000000000000000000000000');
    for (var i = 1; i <= 50; i++) {
        (function(index) { 
            setTimeout(function() { 
                console.log(index);
                console.log('FLAG = '+window.frames[0].window.carregado);

                if (window.frames[0].window.carregado == true ||  window.frames[0].window.errorQlik == true ){
                        setTimeout(function() { 
                            console.log('FLAGENTROU = ENTROU');
                            $('.imageLoading').css('display','none');
                            $('.report').css('visibility','visible').attr('id','animationReport');
                        },2000); 
                }
                
            }, i * 1000);
            //if (window.carregado == true){ break;}
        })(i);
    }
}

